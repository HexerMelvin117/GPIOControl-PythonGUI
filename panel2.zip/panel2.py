from Tkinter import *
from ttk import *
import tkFont
import tkMessageBox
import time
import os

#hola
#Creating Windows
v0 = Tk()
v0.title("Dashboard GPIO")
v0.geometry("800x400+0+0")

#Function definition
def gpio17on():
	os.system("sudo /./home/pi/gpio17on.sh")

def gpio17off():
        os.system("sudo /./home/pi/gpio17off.sh")

def gpio27on():
	os.system("sudo /./home/pi/gpio27on.sh")

def gpio27off():
	os.system("sudo /./home/pi/gpio27off.sh")

def gpio22on():
	os.system("sudo /./home/pi/gpio22on.sh")

def gpio22off():
	os.system("sudo /./home/pi/gpio22off.sh")

#font settings
text_title=tkFont.Font(family="Helvetica",size=18)
text_normal=tkFont.Font(family="Helvetica",size=12)

#Labels zone
Label_title=Label(v0,text="GPIO PANEL",font=text_title).place(x=200,y=10)
Label_gp=Label(v0,text="GPIO",font=text_normal).place(x=10,y=50)
Label_ac=Label(v0,text="Action",font=text_normal).place(x=100,y=50)
Label_17=Label(v0,text="gpio17",font=text_normal).place(x=40,y=100)
Label_27=Label(v0,text="gpio27",font=text_normal).place(x=340,y=100)
Label_22=Label(v0,text="gpio22",font=text_normal).place(x=240,y=250)

#Image Definition
img_17on=PhotoImage(file="on.gif")
img_17off=PhotoImage(file="off.gif")

#buttons zone
btn_17on=Button(v0,image=img_17on,command=gpio17on).place(x=100,y=100)
btn_17off=Button(v0,image=img_17off,command=gpio17off).place(x=200,y=100)

btn_27on=Button(v0,image=img_17on,command=gpio27on).place(x=400,y=100)
btn_27off=Button(v0,image=img_17off,command=gpio27off).place(x=500,y=100)

btn_22on=Button(v0,image=img_17on,command=gpio22on).place(x=300,y=250)
btn_22off=Button(v0,image=img_17off,command=gpio22off).place(x=400,y=250)
#Final
v0.mainloop()
